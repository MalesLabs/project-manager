<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*	
 *	@author 	: MalesLabs
 *	date		: 27 march, 2016
 *	http://codecanyon.net/user/MalesLabs
 *	http://maleslabs.net
 */

class Install extends CI_Controller
{
    
    
    /***default functin, redirects to login page if no admin logged in yet***/
    public function index()
    {
        $this->load->view('backend/install');
    }
    
}
